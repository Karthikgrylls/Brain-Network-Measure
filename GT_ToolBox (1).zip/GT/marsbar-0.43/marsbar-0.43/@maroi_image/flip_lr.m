function o = flip_lr(o)
% flips ROI left / right
%
% $Id  

% Requires change to ROI data -> return as maroi_matrix

o = flip_lr(maroi_matrix(o));
