function res = native_vol_ver(obj)
% return string specifying native vol type
%
% $Id: verbose.m 87 2004-01-06 01:48:35Z matthewbrett $  
  
res = '5';